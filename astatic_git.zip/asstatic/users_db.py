import sqlite3
import os

class UserDB():
	def __init__(self, path):
		self.path = path
		self.prepareDB()

	def prepareDB(self):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()
		cursor.execute('''CREATE TABLE IF NOT EXISTS Users (name TEXT, email TEXT, password TEXT, ip TEXT)''')
		users_base.commit()
		users_base.close()

	def existName(self, name):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		res = cursor.execute('''SELECT name FROM Users''').fetchall()

		users_base.commit()
		users_base.close()

		res = [i[0] for i in res]
		return name in res
		
	def addUser(self, name, email, password, ip):

		if self.existName(name):
			return

		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		cursor.execute('''INSERT INTO Users(name, email, password, ip) VALUES('{0}', '{1}', '{2}', '{3}')'''.format(name, email, password, ip))

		users_base.commit()
		users_base.close()


	def getUserByName(self, name):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		res = cursor.execute('''SELECT * FROM Users WHERE name = '{0}\''''.format(name)).fetchall()

		users_base.commit()
		users_base.close()

		if len(res) == 0:
			return False

		return list(res[0])


	def getUserByIp(self, ip):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		res = cursor.execute('''SELECT * FROM Users WHERE ip = '{0}\''''.format(ip)).fetchall()

		users_base.commit()
		users_base.close()

		if len(res) == 0:
			return False

		return list(res[0])

	def log_in(self, name, ip):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		res = cursor.execute('''UPDATE Users SET ip = '{0}' WHERE name = '{1}\''''.format(ip, name)).fetchall()

		users_base.commit()
		users_base.close()


	def log_out(self, ip):
		users_base = sqlite3.connect(self.path)
		cursor = users_base.cursor()

		res = cursor.execute('''UPDATE Users SET ip = '' WHERE ip = '{0}\''''.format(ip)).fetchall()

		users_base.commit()
		users_base.close()
		