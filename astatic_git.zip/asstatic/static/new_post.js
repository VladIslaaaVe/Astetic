(() => {

const fileInput = document.getElementById("file_input");
const tagsInput = document.getElementById("tags_input");
const tagsBlock = document.getElementById("tags_block");
const sendBtn = document.getElementById("send_btn");

tagsInput.addEventListener("keydown", e => {
	if (e.code === "Enter") {
		e.preventDefault();

		let value = tagsInput.value.replaceAll(/\W/g, "");
		tagsInput.value = "";

		if (tagsBlock.childNodes.length >= 5) return;

		let tag = document.createElement("div");
		tag.classList.add("add_post_tag"); 
		tag.classList.add("post_tag"); 
		tag.innerHTML = value;

		tag.onclick = function () {
			this.remove();
		};

		tagsBlock.appendChild(tag);
	}
});

const sendData = function (file, tags) {
	return new Promise(async function (resolve) {
		let formData = new FormData();
    	formData.append("file", file, "file.png");
    	formData.append("tags", tags);

    	await fetch(window.location.pathname, {
    		body: formData,
    		method: "POST",
    	});

    	resolve();
	});
};

sendBtn.addEventListener("click", async function () {
	let tagsList = [];
	for (let i of tagsBlock.childNodes) {
		tagsList.push(i.innerHTML); 
	}

	let tagsStr = tagsList.join(" ");

	let file = fileInput.files[0];

	if (tagsStr === "" || !file) return;

	await sendData(file, tagsStr);
	window.location.href = "/";
});

})();