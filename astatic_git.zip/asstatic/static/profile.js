(() => {

const exit_btn = document.getElementById("exit_btn");

exit_btn.addEventListener("click", async function () {
	await fetch(window.location.pathname, {
		method: 'POST',
		headers: { 'Content-Type': 'application/json;charset=utf-8' },
		body: JSON.stringify({exit: "exit"}),
	});

	window.location.href = "/";
});

})();