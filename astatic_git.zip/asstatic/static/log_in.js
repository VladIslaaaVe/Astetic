(() => {

const logInBtn = document.getElementById("log_in_btn");

const fields = document.querySelectorAll(".field_input");
const nameField = document.getElementById("name_field");
const passwordField = document.getElementById("password_field");

const nameHint = document.getElementById("name_hint");
const passwordHint = document.getElementById("password_hint");

// войти
const logInRequest = function (name, password) {
	return new Promise(async function (resolve) {
		let data = {name, password};

		let response = await fetch(window.location.pathname, {
			method: 'POST',
		  	headers: { 'Content-Type': 'application/json;charset=utf-8' },
		  	body: JSON.stringify(data),
		});

		resolve(await response.json());
	});
};

logInBtn.addEventListener("click", async function() {
	let fail = false;

	for (let i of fields) {
		if (!i.value) {
			i.classList.add("error");
			fail = true;
		} 
	}

	if (fail) return;

	let name = nameField.value;
	let password = passwordField.value;

	let res = await logInRequest(name, password);
	
	if (res.status === "success") {
		window.location.href = "/";
		return;
	}

	if (res.reason === "invalid name") {
		nameField.classList.add("error");
		nameHint.classList.add("show");
	}

	if (res.reason === "wrong password") {
		passwordField.classList.add("error");
		passwordHint.classList.add("show");
	}
});

for (let i of fields) i.addEventListener("click", e => e.target.classList.remove("error"));

nameField.addEventListener("click", () => {
	nameHint.classList.remove("show");
});

passwordField.addEventListener("click", () => {
	passwordHint.classList.remove("show");
});

})();