(() => {

// ищем элементы
const nameField = document.getElementById("name_field");
const emailField = document.getElementById("email_field");
const passwordField = document.getElementById("password_field");

const nameHint = document.getElementById("name_hint");

const fields = document.querySelectorAll(".field_input");

const signUpBtn = document.getElementById("sign_up_btn");

const signUpRequest = function (name, email, password) {
	return new Promise(async function (resolve) {
		let data = {name, email, password};

		let response = await fetch(window.location.pathname, {
			method: 'POST',
		  	headers: { 'Content-Type': 'application/json;charset=utf-8' },
		  	body: JSON.stringify(data),
		});

		resolve(await response.json());
	});
};

// при клике
signUpBtn.addEventListener("click", async function () {
	let fail = false;

	for (let i of fields) {
		if (!i.value) {
			i.classList.add("error");
			fail = true;
		} 
	}

	if (fail) return;

	let name = nameField.value;
	let email = emailField.value;
	let password = passwordField.value;

	const emailCheck = /\w+\@\w+\.(ru|com)/;

	if (!emailCheck.test(email)) {
		emailField.classList.add("error");
		return;
	}

	let res = await signUpRequest(name, email, password);
	
	if (res.status === "success") {
		window.location.href = "/";
		return;
	}

	nameField.classList.add("error");
	nameHint.classList.add("show");
});

for (let i of fields) i.addEventListener("click", e => e.target.classList.remove("error"));

nameField.addEventListener("click", () => {
	nameHint.classList.remove("show");
});

})();