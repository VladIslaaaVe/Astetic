(() => {

const searchBlock = document.getElementById("search");
const searchRow = document.getElementById("search_row");
const searchInput = document.getElementById("search_input");
const searchBtn = document.getElementById("search_btn");
const hideBtn = document.getElementById("search_hide_btn");

const noResult = document.querySelector(".noResults");

const feedBlock = document.querySelector(".feed");

const feed = document.getElementById("posts_block");

hideBtn.addEventListener("click", () => {
	hideBtn.classList.toggle("active");
	searchBlock.classList.toggle("hide");
	searchRow.classList.toggle("hide");
	feedBlock.classList.toggle("noPadding");
});

searchInput.addEventListener("keydown", e => {
	if (e.code === "Enter") {
		e.preventDefault();
		search();
	} 
});

//адаптив картинок
//опорный размер
let blockSize = 0;

const resizeImg = async function (block) {
	img = block.childNodes[1];
	height = Math.floor(img.naturalHeight * blockSize / img.naturalWidth);
	img.style.width = `${blockSize}px`;
	block.style.height = img.style.height = `${height}px`;
};

const resizeImgs = function () {
	blockSize = Math.min(528 - 34 * 2, innerWidth - 20 * 2 - 34 * 2);
	const imgContainers = document.querySelectorAll(".post_img_block");
	for (let i of imgContainers) resizeImg(i);
};

window.resizeImgs = resizeImgs;

window.addEventListener("load", resizeImgs);
window.addEventListener("resize", resizeImgs);

//искать тег
const searchMe = function (elem) {
	searchInput.value = elem.textContent;
	search();
};

window.searchMe = searchMe;

// получение картинок с сервера
// прошлый запрос
let lastTag = "";
let loaded = 0;
let scrollUpdate = true;

const getPosts = function (tag, loaded) {

	return new Promise(async function (resolve) {
		const request = {
			action: "search",

			tag: tag,
			loaded: loaded,
		};

		const data = await fetch(window.location.pathname, {
			method: "POST",
			headers: { 'Content-Type': 'application/json;charset=utf-8' },
		  	body: JSON.stringify(request),
		});

		resolve(await data.json());
	});	
};

const createPost = function (postData) {
	const username = postData.username;
	const imgPath = postData.imgPath;
	const likes = postData.likes;
	const id = postData.id;

	const tags = postData.tags.split(" ");

	let tagsStr = "";
	for (let i of tags) {
		if (i === "all") continue;
		tagsStr += `<div class="post_tag pointer" onclick="searchMe(this)">${i}</div>`;
	}

	const content = `
	<div class="title post_title">Post by ${username}</div>
	<div class="post_img_block">
		<img onload="resizeImgs()" class="post_img" src="${imgPath}">
	</div>
	<div class="post_columns">
		<div class="post_tags">
			<div class="tags_text">tags</div>
			${tagsStr}
		</div>
		<div class="like_block"><div class="like_text">Нравится: ${likes}</div><div class="like_btn" data-id="${id}" onclick="likePost(this)"></div></div>
	</div>`;

	const postBlock = document.createElement("div");
	postBlock.classList.add("post");
	postBlock.innerHTML = content;
	return postBlock;
};

const search = async function () {
	if (!searchInput.value) searchInput.value = "all";

	scrollUpdate = false;

	let tag = searchInput.value;

	if (lastTag !== tag) {
		while (feed.firstChild) feed.removeChild(feed.firstChild);
	}

	lastTag = tag;

	let imgsData = await getPosts(tag, feed.childNodes.length);

	for (let i of imgsData) {
		const post = createPost(i);
		feed.appendChild(post);
	}

	resizeImgs();

	if (imgsData.length === 0 && feed.childNodes.length === 0) {
		noResult.classList.add("show");
	} else {
		noResult.classList.remove("show");
	}

	scrollUpdate = true;
};

const likePost = async function (likeBtn) {
	const postId = likeBtn.dataset.id;

	const response = await fetch(window.location.pathname, {
		method: "POST",
		headers: { 'Content-Type': 'application/json;charset=utf-8' },
	  	body: JSON.stringify({action: "like", id: postId}),
	});

	const data = await response.json();

	const likesCount = data["likesCount"];

	const parent = likeBtn.closest(".like_block");

	const likeText = Array.from(parent.childNodes).find(e => e.classList.contains("like_text"));

	likeText.innerHTML = `Нравится: ${likesCount}`;
};

window.likePost = likePost;

window.addEventListener("load", () => {
	search();
	//resizeImgs();
});

window.addEventListener("scroll", e => {
	if (!scrollUpdate) return;
	if (window.scrollY + innerHeight >= document.documentElement.scrollHeight) {
		search();
	}
});

})();