import os
import json
from flask import Flask, url_for, request, redirect
from users_db import UserDB
from posts_db import PostsDB


PACK_LEN = 10


userDB = UserDB("databases/users.db")
postsDB = PostsDB("databases/posts.db")

app = Flask(__name__, static_folder="static")

UPLOAD_FOLDER = 'static\\imgs'
ALLOWED_EXTENSIONS = set(["png", "jpg", "jpeg"])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def getHTML(name):
    html = ""
    with open("static/" + name, "r", encoding="utf-8") as file:
        html = file.read()

    return html

# поиск
def search (data):
    posts = postsDB.posts_for_tag(data["tag"])

    if data["loaded"] >= len(posts):
        return []

    posts = posts[data["loaded"]::]

    res = []

    for i in posts:
        res.append({
            "id": i[0],
            "username": i[1],
            "imgPath": i[2],
            "tags": i[3],
            "likes": i[4],
            "likesByUsers": i[5],
        })

    if len(res) > PACK_LEN:
        res = res[0: PACK_LEN]

    return res

def like(data):
    ip = request.remote_addr
    username = userDB.getUserByIp(ip)[0]

    likesByUsers = postsDB.getById(data["id"])[5].split(" ")

    if username in likesByUsers:
        likesByUsers.remove(username)
        postsDB.dislike(data["id"], " ".join(likesByUsers))
    else:
        postsDB.like(data["id"], username)

    likesCount = postsDB.getById(data["id"])[4]
    return {"likesCount": likesCount}

# главная страница
@app.route('/', methods=['POST', 'GET'])
@app.route('/root', methods=['POST', 'GET'])
def root():
    if request.method == "GET":
        ip = request.remote_addr
        user = userDB.getUserByIp(ip)

        if not user:
            html = getHTML("guest.html")
            css_path = url_for("static", filename="style.css")
            return html.format(stylepath=css_path)

        html = getHTML("root.html")
        css_path = url_for("static", filename="style.css")
        js_path = url_for("static", filename="root.js")

        return html.format(stylepath=css_path, jspath=js_path, username=user[0])

    data = request.get_json()

    if data["action"] == "search":
       return json.dumps(search(data))
    elif data["action"] == "like":
        return json.dumps(like(data))


# добавить пост
@app.route('/new_post', methods=['POST', 'GET'])
def add_post_page():
    if request.method == 'GET':
        html = getHTML("new_post.html")
        css_path = url_for("static", filename="style.css")
        js_path = url_for("static", filename="new_post.js")

        return html.format(stylepath=css_path, jspath=js_path)

    ip = request.remote_addr
    name = userDB.getUserByIp(ip)[0]

    file = request.files['file']
    tags = request.form["tags"]

    if not file:
        return "hren"

    filename = file.filename

    num_files = len([f for f in os.listdir(UPLOAD_FOLDER)
                    if os.path.isfile(os.path.join(UPLOAD_FOLDER, f))])

    path = os.path.join(app.config['UPLOAD_FOLDER'], "img{0}.png".format(num_files))
    file.save(path)

    postsDB.add(name, path, tags)

    return redirect(url_for("root"))


# профиль
@app.route('/profile', methods=['POST', 'GET'])
def profile():
    ip = request.remote_addr

    if request.method == 'GET':
        user = userDB.getUserByIp(ip)

        if not user:
            return redirect(url_for("log_in_page"))

        html = getHTML("profile.html")
        css_path = url_for("static", filename="style.css")
        js_path = url_for("static", filename="profile.js")

        return html.format(stylepath=css_path, jspath=js_path, username=user[0], email=user[1], password=user[2])

    userDB.log_out(ip)
    return ""


# регистрация
def sign_up(data):
    name = data["name"]
    email = data["email"]
    password = data["password"]

    if userDB.existName(name):
        response = {
            "status": "error",
            "reason": "existing name",
        }

        return response

    ip = request.remote_addr
    userDB.log_out(ip)
    userDB.addUser(name, email, password, ip)

    response = {
        "status": "success",
        "reason": "",
    }

    return response


# страница регистрации
@app.route('/sign_up', methods=['POST', 'GET'])
def sign_up_page():
    if request.method == 'GET':
        html = getHTML("sign_up.html")
        css_path = url_for("static", filename="style.css")
        js_path = url_for("static", filename="sign_up.js")

        return html.format(stylepath=css_path, jspath=js_path)

    # обрабатываем форму регистрации
    res = sign_up(request.get_json())
    return json.dumps(res)


# вход
def log_in(data):
    name = data["name"]
    password = data["password"]

    user = userDB.getUserByName(name)

    if not user:
        res = {
            "status": "error",
            "reason": "invalid name",
        }

        return res

    if user[2] != password:
        res = {
            "status": "error",
            "reason": "wrong password",
        }

        return res

    ip = request.remote_addr
    userDB.log_out(ip)
    userDB.log_in(user[0], ip)

    res = {
        "status": "success",
        "reason": "",
    }

    return res


# вход
@app.route('/log_in', methods=['POST', 'GET'])
def log_in_page():
    if request.method == 'GET':
        html = getHTML("log_in.html")
        css_path = url_for("static", filename="style.css")
        js_path = url_for("static", filename="log_in.js")
        return html.format(stylepath=css_path, jspath=js_path)

    # обрабатываем форму входа
    res = log_in(request.get_json())
    return json.dumps(res)

if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")