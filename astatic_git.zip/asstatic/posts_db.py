import sqlite3
import os


class PostsDB():
    def __init__(self, path):
        self.path = path
        self.prepareBD()

    def prepareBD(self):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS Posts (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, img_path TEXT, tags TEXT, likes INT, LikesByUsers TEXT)''')
        users_base.commit()
        users_base.close()

    def getById(self, postId):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        res = cursor.execute('''SELECT * FROM Posts WHERE id = {0}'''.format(postId)).fetchall()

        users_base.commit()
        users_base.close()

        return res[0]

    def find(self, tag):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        res = cursor.execute('''SELECT * FROM Posts WHERE CHARINDEX('{0}', tags) != 0'''.format(tag)).fetchall()

        users_base.commit()
        users_base.close()

        return res

    def add(self, username, img_path, tags):
        tags = "all " + tags

        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        cursor.execute('''INSERT INTO Posts(username, img_path, tags, likes, LikesByUsers) VALUES('{0}', '{1}', '{2}', 0, "")'''.format(username, img_path, tags))

        users_base.commit()
        users_base.close()

    def delete(self, postId):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        cursor.execute('''DELETE FROM Posts WHERE id = {0}'''.format(postId))

        users_base.commit()
        users_base.close()

    def like(self, postId, user):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        cursor.execute('''UPDATE Posts SET likes = likes + 1 WHERE id = '{0}\''''.format(postId))
        cursor.execute('''UPDATE Posts SET LikesByUsers = LikesByUsers || '{1}' WHERE id = '{0}\''''.format(postId, user + " "))

        users_base.commit()
        users_base.close()

    def dislike(self, postId, user):
        users_base = sqlite3.connect(self.path)
        cursor = users_base.cursor()

        cursor.execute('''UPDATE Posts SET likes = likes - 1 WHERE id = '{0}\''''.format(postId))
        cursor.execute('''UPDATE Posts SET LikesByUsers = '{1}' WHERE id = '{0}\''''.format(postId, user))

        users_base.commit()
        users_base.close()


    def posts_for_tag(self, tag):
        posts_base = sqlite3.connect(self.path)
        cursor = posts_base.cursor()
        res = cursor.execute(
            '''SELECT * FROM Posts WHERE tags like "%''' + tag + '''%" ORDER BY likes DESC''').fetchall()

        return res